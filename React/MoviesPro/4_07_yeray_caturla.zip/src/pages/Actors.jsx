import React from "react"
import AllActors from "../components/AllActors.jsx"

const Actors = () => {
    return <>
        <AllActors></AllActors>
    </>
}

export default Actors