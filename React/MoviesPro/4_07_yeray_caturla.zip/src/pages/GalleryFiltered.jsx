import React from "react"
import "./GalleryFiltered.css"

//The view of the gallery filtered
const GalleryFiltered = ({ title }) => {
    return <div className="galleryFiltered_container">{title}</div>
}

export default GalleryFiltered
