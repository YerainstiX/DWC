import React from "react"
import "./Start.css"

//The main page
const Start = () => {
    return (
        <>
            <div className="start_container">
                <h1>Ugly start page</h1>
            </div>
        </>
    )
}

export default Start
