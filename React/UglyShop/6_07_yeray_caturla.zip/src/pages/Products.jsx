import React from "react"
import "./Products.css"
const Products = () => {
    return <div className="products_container">WORK IN PROGRESS</div>
}

export default Products
