import React from "react"
import "./Footer.css"
const Footer = () => {
    return (
        <>
            <footer>
                © 2026 Site for ugly people . All right reserved except if you
                are handsome
            </footer>
        </>
    )
}

export default Footer
