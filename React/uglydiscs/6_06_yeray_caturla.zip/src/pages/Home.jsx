import React from "react"
import "./Home.css"
const Home = () => {
    return (
        <div className="start_container">
            <h1>Ugly Home page</h1>
        </div>
    )
}

export default Home
