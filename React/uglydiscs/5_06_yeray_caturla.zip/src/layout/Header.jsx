import React from 'react'
import Menu from './Menu'

const Header = () => {
  return (
    <>
    <Menu pageName="Ugly Discs"></Menu>
    </>
  )
}

export default Header
