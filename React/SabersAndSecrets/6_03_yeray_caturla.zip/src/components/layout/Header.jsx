import React from 'react'
import Menu from './Menu'

const Header = () => {
  return (
    <>
    <Menu pageName="SABERS & SECRETS"></Menu>
    </>
  )
}

export default Header
