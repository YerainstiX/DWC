import React from "react"
import "./Footer.css"
const Footer = () => {
    return (
        <>
            <footer>
                © 2025 Sitio para feos. Todos los derechos reservados menos si
                eres un cardo.
            </footer>
        </>
    )
}

export default Footer
