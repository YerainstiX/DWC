import React from "react"
import "./Start.css"
//The start page.
const Start = () => {
    return (
        <>
            <div className="start_container">
                <h1>Start page</h1>
            </div>
        </>
    )
}

export default Start
