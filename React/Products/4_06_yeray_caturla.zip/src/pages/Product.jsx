import React from "react"
import ButtonNavigate from "../components/ButtonNavigate.jsx"
import "./Product.css"
//The product page.
const Products = () => {
    return (
        <>
            <div className="product_container">
                <h1>Product page</h1>
                <ButtonNavigate></ButtonNavigate>
            </div>
        </>
    )
}

export default Products
