import React from "react"
import ButtonNavigate from "../components/ButtonNavigate.jsx"
import "./Contact.css"
//The contact page
const Contact = () => {
    return (
        <>
            <div className="contact_container">
                <h1>Contact page</h1>
                <ButtonNavigate></ButtonNavigate>
            </div>
        </>
    )
}

export default Contact
