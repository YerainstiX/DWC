"use strict"

import { showMultiplesOf3 } from "./library/function.js"

console.log(showMultiplesOf3(10))
