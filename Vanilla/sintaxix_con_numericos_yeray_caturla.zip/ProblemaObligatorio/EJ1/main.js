"use strict"

import { showMonth } from "./library/function.js"

console.log(showMonth(5))
