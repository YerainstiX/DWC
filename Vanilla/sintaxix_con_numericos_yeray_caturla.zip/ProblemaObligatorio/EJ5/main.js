"use strict"

import { arithmeticMedia } from "./library/function.js"

console.log(arithmeticMedia(3, 5, 3))
