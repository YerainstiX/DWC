"use strict"

import { power } from "./library/function.js"

console.log(power(2, 6))
