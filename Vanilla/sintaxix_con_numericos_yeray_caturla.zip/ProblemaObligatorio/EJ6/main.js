"use strict"

import { calculator } from "./library/function.js"

console.log(calculator(1, 1, "/"))
