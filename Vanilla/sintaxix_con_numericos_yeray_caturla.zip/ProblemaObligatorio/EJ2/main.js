"use strict"

import { numberAnalysis } from "./library/function.js"

console.log(numberAnalysis(3))
