"use strict"

//I added it at the ex1 object

